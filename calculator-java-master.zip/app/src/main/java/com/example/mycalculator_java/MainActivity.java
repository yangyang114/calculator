package com.example.mycalculator_java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView tv_result;
    private String operator = ""; // 操作符
    private String firstNum = ""; // 前一个操作数
    private String nextNum = ""; // 后一个操作数


    /*
        设置firstNum、nextNum、operator的值，并设置显示
     */
    private void setMyValue( String myvalue){
        if(operator.equals("√")){
            nextNum = nextNum + myvalue;
        }
        else {
            if (firstNum.trim().equals("")) {
                firstNum = firstNum + myvalue;
            } else {
                if (operator.equals("")) {
                    firstNum = firstNum + myvalue;
                } else {

                    nextNum = nextNum + myvalue;

                }
            }
        }
        ShowDisplayBar();
    }


    /*
        变量初始化清空
     */
    private void InitZero(){
        // 清空并初始化
        tv_result.setText("");
        operator = "";
        firstNum = "";
        nextNum = "";
    }

    /*
        Cancel 操作
     */
    private void CancelDO(){
        if(!nextNum.equals("")){
            nextNum = "";
        }
        else{
            if(!operator.equals("")){
                operator = "";
            }
            else{
                firstNum = "";
            }
        }
        ShowDisplayBar();
    }

    /*
        在计数器的显示栏显示
     */
    private void ShowDisplayBar(){

        tv_result.setText(String.format(getResources().getString(R.string.display_Bar),firstNum,operator,nextNum));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        tv_result = (TextView) findViewById(R.id.tv_result);
        tv_result.setMovementMethod(new ScrollingMovementMethod());



        /*
        btn_cancel
         */
        Button btn_cancel = findViewById(R.id.btn_cancel);
        /*
        未使用 lambda 表达式的老写法
        btn_cancel.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {

            }
        });
        */
        btn_cancel.setOnClickListener(View ->CancelDO());

        /*
        btn_plus 加号
        */
        Button btn_plus = findViewById(R.id.btn_plus);
        btn_plus.setOnClickListener(View ->{
            operator = "+";
            ShowDisplayBar();
        });

        /*
        btn_minus  减号
        */
        Button btn_minus = findViewById(R.id.btn_minus);
        btn_minus.setOnClickListener(View ->{
            if(nextNum.equals("")&&!operator.equals("")){
                nextNum = "-";
            }
            else {
                operator = "-";
            }
            ShowDisplayBar();

        });

         /*
        btn_multiply 乘号
         */
        Button btn_multiply = findViewById(R.id.btn_multiply);
        btn_multiply.setOnClickListener(View ->{
            operator = "X";
            ShowDisplayBar();

        });

        /*
        btn_divide 除号
         */
        Button btn_divide = findViewById(R.id.btn_divide);
        btn_divide.setOnClickListener(View ->{
            operator = "÷";
            ShowDisplayBar();
        });

         /*
        btn_equal  等号计算
        */
        Button btn_equal = findViewById(R.id.btn_equal);
        btn_equal.setOnClickListener(View -> {
            String Temp ;
                Temp = firstNum.equals("")?"0":firstNum;
            Double leftNo = Double.valueOf(Temp);
                Temp = nextNum.equals("")?"0":nextNum;
            Double rightNo = Double.valueOf(Temp);
            double result = 0.00;
            switch (operator){
                case "+" :
                    result = leftNo + rightNo;
                    break;
                case "-" :
                    result = leftNo - rightNo;
                    break;
                case "X" :
                    result = leftNo * rightNo;
                    break;
                case "÷" :
                    result = leftNo / rightNo;
                    break;
                case "√":
                    result = Math.sqrt(rightNo);
                    break;
            }
            tv_result.setText(String.valueOf(result));
            firstNum = "";
            nextNum = "";
            operator = "";
        });

        /*
        btn_clear 初始化清空
        */
        Button btn_clear = findViewById(R.id.btn_clear);
        btn_clear.setOnClickListener(View -> InitZero());

        /*
        btn_seven
        */
        Button btn_seven = findViewById(R.id.btn_seven);
        btn_seven.setOnClickListener(View -> setMyValue("7"));

        /*
        btn_eight
        */
        Button btn_eight = findViewById(R.id.btn_eight);
        btn_eight.setOnClickListener(View -> setMyValue("8"));

        /*
        btn_nine
        */
        Button btn_nine = findViewById(R.id.btn_nine);
        btn_nine.setOnClickListener(View -> setMyValue("9"));



        /*
        btn_four
        */
        Button btn_four = findViewById(R.id.btn_four);
        btn_four.setOnClickListener(View -> setMyValue("4"));

        /*
        btn_five
        */
        Button btn_five = findViewById(R.id.btn_five);
        btn_five.setOnClickListener(View -> setMyValue("5"));

        /*
        btn_six
        */
        Button btn_six = findViewById(R.id.btn_six);
        btn_six.setOnClickListener(View -> setMyValue("6"));



        /*
        btn_one
        */
        Button btn_one = findViewById(R.id.btn_one);
        btn_one.setOnClickListener(View -> setMyValue("1"));

        /*
        btn_two
        */
        Button btn_two = findViewById(R.id.btn_two);
        btn_two.setOnClickListener(View -> setMyValue("2"));

        /*
        btn_three
        */
        Button btn_three = findViewById(R.id.btn_three);
        btn_three.setOnClickListener(View -> setMyValue("3"));

        /*
        btn_zero
        */
        Button btn_zero = findViewById(R.id.btn_zero);

        btn_zero.setOnClickListener(View -> setMyValue("0"));

         /*
        btn_dot
        */
        Button btn_dot = findViewById(R.id.btn_dot);
        btn_dot.setOnClickListener(View ->{
            if(!nextNum.equals("")){
                nextNum = nextNum +".";
            }
            else{
                if(operator.equals("")){
                    if(!firstNum.equals("")) {
                        firstNum = firstNum + ".";
                    }
                    else {
                        firstNum = "0.";
                    }
                }
            }
            ShowDisplayBar();
        });



        /*
        ib_sqrt 平方根
        */
        Button ib_sqrt = findViewById(R.id.ib_sqrt);
        ib_sqrt.setOnClickListener(View ->{
            if(firstNum.equals("")){
                operator = "√";
                ShowDisplayBar();
            }
            else{

                tv_result.setText("请按【C】，再按√，最后选择数字！");
            }

        });

    }
}